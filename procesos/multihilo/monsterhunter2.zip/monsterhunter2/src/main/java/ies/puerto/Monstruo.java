package ies.puerto;

import java.util.Random;

public class Monstruo{

    private String nombre;
    
    public Monstruo(String nombre) {
        this.nombre = nombre;
    }
}
